namespace Clases{

   export enum tipoMascota{
        Perro,
        Gato,
        Reptil,
        Roedor,
        Ave,
        Pez
    }

}