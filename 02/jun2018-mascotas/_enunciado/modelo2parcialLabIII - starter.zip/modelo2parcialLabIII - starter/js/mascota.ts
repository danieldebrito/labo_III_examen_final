namespace Clases{

    export class Mascota extends Animal{


    }
}

